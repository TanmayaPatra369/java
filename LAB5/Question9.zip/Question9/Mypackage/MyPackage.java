package Question9.Mypackage;

// MyPackage.java


public class MyPackage {
    public void display() {
        System.out.println("Inside MyPackage");
    }
}