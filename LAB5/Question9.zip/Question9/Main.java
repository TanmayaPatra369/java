package Question9;

import Question9.Mypackage.MyPackage;

public class Main {
    public static void main(String[] args) {
        MyPackage myPackage = new MyPackage();
        myPackage.display();
    }
}
